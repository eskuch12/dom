package com.moodarchive.app.presentation.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moodarchive.app.core.navigation.Route
import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.presentation.components.MoodBottomBar
import kotlinx.coroutines.flow.StateFlow
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsScreen(
    entries: List<MoodEntry>,
    selectedMonthFlow: StateFlow<YearMonth>,
    currentRoute: Route,
    onMonthChange: (YearMonth) -> Unit,
    onNavigate: (Route) -> Unit,
) {
    val month by selectedMonthFlow.collectAsStateWithLifecycle()
    val monthEntries = entries.filter {
        YearMonth.from(it.createdAt.atZone(ZoneId.systemDefault())) == month
    }
    val total = monthEntries.size.coerceAtLeast(1)
    val stats = Emotion.entries.mapNotNull { emotion ->
        val count = monthEntries.count { it.emotion == emotion }
        if (count == 0) null else Triple(emotion, count, count / total.toFloat())
    }.sortedByDescending { it.second }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Статистика") }) },
        bottomBar = { MoodBottomBar(currentRoute, onNavigate) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                IconButton(onClick = { onMonthChange(month.minusMonths(1)) }) {
                    Icon(Icons.Outlined.ChevronLeft, contentDescription = "Предыдущий месяц")
                }
                Text(month.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleLarge)
                IconButton(onClick = { onMonthChange(month.plusMonths(1)) }) {
                    Icon(Icons.Outlined.ChevronRight, contentDescription = "Следующий месяц")
                }
            }
            EmotionPieChart(
                slices = stats.map { it.first.color to it.third },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
            )
            if (stats.isEmpty()) {
                Text("За месяц пока нет данных", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                stats.forEach { (emotion, count, percent) ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(12.dp)
                                    .background(emotion.color, CircleShape),
                            )
                            Text(
                                "${emotion.label}: $count (${(percent * 100).toInt()}%)",
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                        LinearProgressIndicator(
                            progress = { percent },
                            modifier = Modifier.fillMaxWidth(),
                            color = emotion.color,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmotionPieChart(
    slices: List<Pair<Color, Float>>,
    modifier: Modifier = Modifier,
) {
    val fallback = MaterialTheme.colorScheme.surfaceVariant
    Canvas(modifier = modifier) {
        if (slices.isEmpty()) {
            drawCircle(color = fallback, radius = size.minDimension / 3)
            return@Canvas
        }
        var startAngle = -90f
        val diameter = size.minDimension * 0.82f
        val topLeft = androidx.compose.ui.geometry.Offset(
            x = (size.width - diameter) / 2f,
            y = (size.height - diameter) / 2f,
        )
        slices.forEach { (color, percent) ->
            val sweep = percent * 360f
            drawArc(
                color = color,
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = true,
                topLeft = topLeft,
                size = Size(diameter, diameter),
            )
            startAngle += sweep
        }
    }
}
