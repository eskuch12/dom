package com.moodarchive.app.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface MoodEntryDao {
    @Query("SELECT * FROM mood_entries WHERE syncState != 'PendingDelete' ORDER BY createdAtEpochMs DESC")
    fun observeEntries(): Flow<List<MoodEntryEntity>>

    @Query("SELECT * FROM mood_entries WHERE id = :id LIMIT 1")
    fun observeEntry(id: String): Flow<MoodEntryEntity?>

    @Query(
        """
        SELECT * FROM mood_entries
        WHERE syncState != 'PendingDelete'
        AND createdAtEpochMs BETWEEN :startEpochMs AND :endEpochMs
        ORDER BY createdAtEpochMs DESC
        """,
    )
    fun observeEntriesBetween(startEpochMs: Long, endEpochMs: Long): Flow<List<MoodEntryEntity>>

    @Query(
        """
        SELECT * FROM mood_entries
        WHERE syncState != 'PendingDelete'
        AND (:query = '' OR text LIKE '%' || :query || '%')
        AND (:emotion IS NULL OR emotion = :emotion)
        AND (:startEpochMs IS NULL OR createdAtEpochMs BETWEEN :startEpochMs AND :endEpochMs)
        ORDER BY createdAtEpochMs DESC
        """,
    )
    fun search(
        query: String,
        emotion: String?,
        startEpochMs: Long?,
        endEpochMs: Long?,
    ): Flow<List<MoodEntryEntity>>

    @Query("SELECT * FROM mood_entries WHERE syncState IN ('PendingUpload', 'PendingDelete', 'Failed')")
    suspend fun pendingSync(): List<MoodEntryEntity>

    @Upsert
    suspend fun upsert(entry: MoodEntryEntity)

    @Upsert
    suspend fun upsertAll(entries: List<MoodEntryEntity>)

    @Query("UPDATE mood_entries SET syncState = :syncState, updatedAtEpochMs = :updatedAtEpochMs WHERE id = :id")
    suspend fun updateSyncState(id: String, syncState: String, updatedAtEpochMs: Long)

    @Query("DELETE FROM mood_entries WHERE id = :id")
    suspend fun deleteById(id: String)
}
