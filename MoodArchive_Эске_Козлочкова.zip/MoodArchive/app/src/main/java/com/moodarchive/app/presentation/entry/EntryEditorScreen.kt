package com.moodarchive.app.presentation.entry

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.KeyboardVoice
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.MediaType
import com.moodarchive.app.presentation.EditorState
import com.moodarchive.app.presentation.components.EmotionChip
import kotlinx.coroutines.flow.StateFlow

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EntryEditorScreen(
    stateFlow: StateFlow<EditorState>,
    onTextChange: (String) -> Unit,
    onEmotionChange: (Emotion) -> Unit,
    onAddAttachment: (MediaType) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onToggleLocation: () -> Unit,
    onBack: () -> Unit,
    onSave: () -> Unit,
) {
    val state by stateFlow.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.entryId == null) "Новая запись" else "Редактирование") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.Close, contentDescription = "Закрыть")
                    }
                },
                actions = {
                    IconButton(onClick = onSave) {
                        Icon(Icons.Outlined.Save, contentDescription = "Сохранить")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            OutlinedTextField(
                value = state.text,
                onValueChange = onTextChange,
                label = { Text("Что хочется сохранить?") },
                minLines = 8,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Эмоция", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Emotion.entries.forEach { emotion ->
                    EmotionChip(
                        emotion = emotion,
                        selected = state.emotion == emotion,
                        onClick = { onEmotionChange(emotion) },
                    )
                }
            }

            Text("Вложения", style = MaterialTheme.typography.titleMedium)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(onClick = { onAddAttachment(MediaType.Photo) }) {
                    Icon(Icons.Outlined.Image, contentDescription = null)
                    Text("Фото")
                }
                OutlinedButton(onClick = { onAddAttachment(MediaType.Video) }) {
                    Icon(Icons.Outlined.Videocam, contentDescription = null)
                    Text("Видео")
                }
                OutlinedButton(onClick = { onAddAttachment(MediaType.Audio) }) {
                    Icon(Icons.Outlined.KeyboardVoice, contentDescription = null)
                    Text("Голос")
                }
                OutlinedButton(onClick = { onAddAttachment(MediaType.File) }) {
                    Icon(Icons.Outlined.AttachFile, contentDescription = null)
                    Text("Файл")
                }
            }

            if (state.attachments.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.attachments.forEach { attachment ->
                        AssistChip(
                            onClick = { },
                            label = { Text(attachment.displayName) },
                            trailingIcon = {
                                IconButton(onClick = { onRemoveAttachment(attachment.id) }) {
                                    Icon(Icons.Outlined.Close, contentDescription = "Удалить вложение")
                                }
                            },
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.LocationOn, contentDescription = null)
                Text("Прикрепить геолокацию", modifier = Modifier.weight(1f).padding(start = 8.dp))
                Switch(checked = state.includeLocation, onCheckedChange = { onToggleLocation() })
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Сохранить запись")
            }
        }
    }
}
