package com.moodarchive.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "moodarchive_settings")

class SettingsStore(private val context: Context) {
    private val darkThemeKey = booleanPreferencesKey("dark_theme")
    private val remindersKey = booleanPreferencesKey("reminders")
    private val pinKey = booleanPreferencesKey("pin_enabled")
    private val pinCodeKey = stringPreferencesKey("pin_code")

    val settings = context.dataStore.data.map { prefs ->
        UserSettings(
            darkTheme = prefs[darkThemeKey] ?: false,
            reminders = prefs[remindersKey] ?: true,
            pinEnabled = prefs[pinKey] ?: true,
            pinCode = prefs[pinCodeKey].orEmpty(),
        )
    }

    suspend fun updateDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[darkThemeKey] = enabled }
    }

    suspend fun updateReminders(enabled: Boolean) {
        context.dataStore.edit { it[remindersKey] = enabled }
    }

    suspend fun updatePin(enabled: Boolean) {
        context.dataStore.edit { it[pinKey] = enabled }
    }

    suspend fun updatePinCode(pinCode: String) {
        context.dataStore.edit {
            it[pinCodeKey] = pinCode
            it[pinKey] = true
        }
    }
}

data class UserSettings(
    val darkTheme: Boolean = false,
    val reminders: Boolean = true,
    val pinEnabled: Boolean = true,
    val pinCode: String = "",
)
