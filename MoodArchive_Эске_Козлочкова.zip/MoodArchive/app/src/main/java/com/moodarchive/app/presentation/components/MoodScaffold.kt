package com.moodarchive.app.presentation.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.moodarchive.app.core.navigation.Route

@Composable
fun MoodBottomBar(
    currentRoute: Route,
    onNavigate: (Route) -> Unit,
) {
    val items = listOf(
        Route.Home to (Icons.Outlined.Home to "Лента"),
        Route.Calendar to (Icons.Outlined.CalendarMonth to "Календарь"),
        Route.Stats to (Icons.Outlined.QueryStats to "Статистика"),
        Route.Search to (Icons.Outlined.Search to "Поиск"),
        Route.Settings to (Icons.Outlined.Settings to "Настройки"),
    )
    NavigationBar {
        items.forEach { (route, iconAndLabel) ->
            NavigationBarItem(
                selected = currentRoute == route,
                onClick = { onNavigate(route) },
                icon = { Icon(iconAndLabel.first, contentDescription = iconAndLabel.second) },
                label = { Text(iconAndLabel.second) },
            )
        }
    }
}
