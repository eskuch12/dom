package com.moodarchive.app.domain.usecase

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.domain.repository.MoodEntryRepository
import java.io.File

class ExportFilesUseCase(
    private val context: Context,
    private val repository: MoodEntryRepository,
) {
    suspend fun markdown(entries: List<MoodEntry>): File {
        val file = exportFile("moodarchive.md")
        file.writeText(repository.exportMarkdown(entries))
        return file
    }

    fun pdf(markdown: String): File {
        val file = exportFile("moodarchive.pdf")
        val document = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
        }
        val lines = markdown.lines()
        var pageNumber = 1
        var index = 0
        while (index < lines.size) {
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
            val page = document.startPage(pageInfo)
            var y = 40f
            while (index < lines.size && y < 800f) {
                page.canvas.drawText(lines[index].take(96), 40f, y, paint)
                y += 18f
                index++
            }
            document.finishPage(page)
            pageNumber++
        }
        file.outputStream().use(document::writeTo)
        document.close()
        return file
    }

    fun shareUri(file: File) =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    private fun exportFile(name: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        return File(dir, name)
    }
}
