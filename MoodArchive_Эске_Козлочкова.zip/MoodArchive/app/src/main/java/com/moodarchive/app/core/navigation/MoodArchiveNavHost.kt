package com.moodarchive.app.core.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.moodarchive.app.presentation.MoodArchiveViewModel
import com.moodarchive.app.presentation.calendar.CalendarScreen
import com.moodarchive.app.presentation.entry.EntryDetailScreen
import com.moodarchive.app.presentation.entry.EntryEditorScreen
import com.moodarchive.app.presentation.home.HomeScreen
import com.moodarchive.app.presentation.search.SearchScreen
import com.moodarchive.app.presentation.security.SecurityScreen
import com.moodarchive.app.presentation.security.SplashWelcomeScreen
import com.moodarchive.app.presentation.settings.SettingsScreen
import com.moodarchive.app.presentation.stats.StatisticsScreen

@Composable
fun MoodArchiveNavHost(viewModel: MoodArchiveViewModel) {
    val navController = rememberNavController()
    val entries = viewModel.entries.collectAsStateWithLifecycle()
    val settings = viewModel.settings.collectAsStateWithLifecycle()

    fun navigateTopLevel(route: Route) {
        navController.navigate(route.value) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    NavHost(
        navController = navController,
        startDestination = Route.Splash.value,
    ) {
        composable(Route.Splash.value) {
            SplashWelcomeScreen(
                onReady = {
                    navController.navigate(Route.Security.value) {
                        popUpTo(Route.Splash.value) { inclusive = true }
                    }
                },
            )
        }
        composable(Route.Security.value) {
            SecurityScreen(
                storedPin = settings.value.pinCode,
                onPinCreated = viewModel::setPinCode,
                onUnlocked = {
                    navController.navigate(Route.Home.value) {
                        popUpTo(Route.Security.value) { inclusive = true }
                    }
                },
            )
        }
        composable(Route.Home.value) {
            HomeScreen(
                entries = entries.value,
                currentRoute = Route.Home,
                onNavigate = ::navigateTopLevel,
                onAdd = {
                    viewModel.startNewEntry()
                    navController.navigate(Route.Editor.value)
                },
                onOpen = { navController.navigate(Route.Detail.create(it.id)) },
                onSync = viewModel::syncNow,
            )
        }
        composable(Route.Editor.value) {
            LaunchedEffect(Unit) {
                viewModel.startNewEntry()
            }
            EntryEditorScreen(
                stateFlow = viewModel.editorState,
                onTextChange = viewModel::updateText,
                onEmotionChange = viewModel::updateEmotion,
                onAddAttachment = viewModel::addAttachment,
                onRemoveAttachment = viewModel::removeAttachment,
                onToggleLocation = viewModel::toggleLocation,
                onBack = { navController.popBackStack() },
                onSave = { viewModel.saveEntry { navController.popBackStack() } },
            )
        }
        composable("editor/{entryId}") { backStackEntry ->
            val entryId = backStackEntry.arguments?.getString("entryId").orEmpty()
            val entry = entries.value.firstOrNull { it.id == entryId }
            LaunchedEffect(entry?.id) {
                if (entry != null) viewModel.editEntry(entry)
            }
            EntryEditorScreen(
                stateFlow = viewModel.editorState,
                onTextChange = viewModel::updateText,
                onEmotionChange = viewModel::updateEmotion,
                onAddAttachment = viewModel::addAttachment,
                onRemoveAttachment = viewModel::removeAttachment,
                onToggleLocation = viewModel::toggleLocation,
                onBack = { navController.popBackStack() },
                onSave = { viewModel.saveEntry { navController.popBackStack() } },
            )
        }
        composable(Route.Detail.value) { backStackEntry ->
            val entryId = backStackEntry.arguments?.getString("entryId").orEmpty()
            val entry = entries.value.firstOrNull { it.id == entryId }
            EntryDetailScreen(
                entry = entry,
                onBack = { navController.popBackStack() },
                onEdit = {
                    entry?.let(viewModel::editEntry)
                    if (entry != null) navController.navigate(Route.Editor.create(entry.id))
                },
                onDelete = {
                    viewModel.deleteEntry(entryId) { navController.popBackStack() }
                },
            )
        }
        composable(Route.Calendar.value) {
            CalendarScreen(
                entries = entries.value,
                selectedDateFlow = viewModel.selectedDate,
                currentRoute = Route.Calendar,
                onDateChange = viewModel::selectDate,
                onNavigate = ::navigateTopLevel,
                onOpen = { navController.navigate(Route.Detail.create(it.id)) },
            )
        }
        composable(Route.Stats.value) {
            StatisticsScreen(
                entries = entries.value,
                selectedMonthFlow = viewModel.selectedMonth,
                currentRoute = Route.Stats,
                onMonthChange = viewModel::selectMonth,
                onNavigate = ::navigateTopLevel,
            )
        }
        composable(Route.Search.value) {
            SearchScreen(
                entries = entries.value,
                queryFlow = viewModel.searchQuery,
                emotionFlow = viewModel.searchEmotion,
                currentRoute = Route.Search,
                onQueryChange = viewModel::setSearchQuery,
                onEmotionChange = viewModel::setSearchEmotion,
                onNavigate = ::navigateTopLevel,
                onOpen = { navController.navigate(Route.Detail.create(it.id)) },
            )
        }
        composable(Route.Settings.value) {
            SettingsScreen(
                exportPreviewFlow = viewModel.exportPreview,
                settingsFlow = viewModel.settings,
                currentRoute = Route.Settings,
                onNavigate = ::navigateTopLevel,
                onSync = viewModel::syncNow,
                onExport = viewModel::generateMarkdownExport,
                onDarkThemeChange = viewModel::setDarkTheme,
                onRemindersChange = viewModel::setReminders,
                onPinChange = viewModel::setPinEnabled,
            )
        }
    }
}
