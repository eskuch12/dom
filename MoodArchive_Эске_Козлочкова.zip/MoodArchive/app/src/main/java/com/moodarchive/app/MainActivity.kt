package com.moodarchive.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.moodarchive.app.core.navigation.MoodArchiveNavHost
import com.moodarchive.app.core.theme.MoodArchiveTheme
import com.moodarchive.app.presentation.MoodArchiveViewModel
import com.moodarchive.app.presentation.MoodArchiveViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: MoodArchiveViewModel = viewModel(
                factory = MoodArchiveViewModelFactory(
                    repository = ServiceLocator.repository,
                    settingsStore = ServiceLocator.settingsStore,
                ),
            )
            val settings by viewModel.settings.collectAsStateWithLifecycle()

            MoodArchiveTheme(darkTheme = settings.darkTheme) {
                MoodArchiveNavHost(viewModel = viewModel)
            }
        }
    }
}
