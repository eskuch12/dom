﻿package com.moodarchive.app.presentation.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moodarchive.app.core.navigation.Route
import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.presentation.components.EmotionChip
import com.moodarchive.app.presentation.components.EntryCard
import com.moodarchive.app.presentation.components.MoodBottomBar
import kotlinx.coroutines.flow.StateFlow

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    entries: List<MoodEntry>,
    queryFlow: StateFlow<String>,
    emotionFlow: StateFlow<Emotion?>,
    currentRoute: Route,
    onQueryChange: (String) -> Unit,
    onEmotionChange: (Emotion?) -> Unit,
    onNavigate: (Route) -> Unit,
    onOpen: (MoodEntry) -> Unit,
) {
    val query by queryFlow.collectAsStateWithLifecycle()
    val emotion by emotionFlow.collectAsStateWithLifecycle()
    val result = entries.filter { entry ->
        val queryMatches = query.isBlank() ||
            entry.text.contains(query, ignoreCase = true) ||
            entry.attachments.any { it.displayName.contains(query, ignoreCase = true) }
        val emotionMatches = emotion == null || entry.emotion == emotion
        queryMatches && emotionMatches
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Поиск") }) },
        bottomBar = { MoodBottomBar(currentRoute, onNavigate) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Ключевые слова") },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = emotion == null,
                    onClick = { onEmotionChange(null) },
                    label = { Text("Все") },
                )
                Emotion.entries.forEach { item ->
                    EmotionChip(
                        emotion = item,
                        selected = emotion == item,
                        onClick = { onEmotionChange(item) },
                    )
                }
            }
            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(result, key = { it.id }) { entry ->
                    EntryCard(entry = entry, onClick = { onOpen(entry) })
                }
            }
        }
    }
}