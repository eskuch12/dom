package com.moodarchive.app.presentation.security

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SecurityScreen(
    storedPin: String,
    onPinCreated: (String) -> Unit,
    onUnlocked: () -> Unit,
) {
    var pin by remember(storedPin) { mutableStateOf("") }
    var repeatedPin by remember(storedPin) { mutableStateOf("") }
    var error by remember(storedPin) { mutableStateOf<String?>(null) }
    val isSetupMode = storedPin.isBlank()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Outlined.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(
            text = if (isSetupMode) "Создайте PIN" else "Вход в дневник",
            style = MaterialTheme.typography.headlineSmall,
        )
        Text(
            text = if (isSetupMode) {
                "PIN будет запрашиваться при запуске приложения."
            } else {
                "Введите PIN для доступа к архиву."
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp),
        )
        OutlinedTextField(
            value = pin,
            onValueChange = {
                pin = it.filter(Char::isDigit).take(6)
                error = null
            },
            label = { Text("PIN") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        if (isSetupMode) {
            OutlinedTextField(
                value = repeatedPin,
                onValueChange = {
                    repeatedPin = it.filter(Char::isDigit).take(6)
                    error = null
                },
                label = { Text("Повторите PIN") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
            )
        }
        error?.let {
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 10.dp),
            )
        }
        Button(
            onClick = {
                if (isSetupMode) {
                    when {
                        pin.length < 4 -> error = "PIN должен содержать минимум 4 цифры"
                        pin != repeatedPin -> error = "PIN не совпадает"
                        else -> {
                            onPinCreated(pin)
                            onUnlocked()
                        }
                    }
                } else if (pin == storedPin) {
                    onUnlocked()
                } else {
                    error = "Неверный PIN"
                    pin = ""
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
        ) {
            Text(if (isSetupMode) "Сохранить PIN" else "Войти")
        }
    }
}
