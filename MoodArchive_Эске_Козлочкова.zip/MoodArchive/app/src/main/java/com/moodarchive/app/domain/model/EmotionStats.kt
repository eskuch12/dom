package com.moodarchive.app.domain.model

data class EmotionStats(
    val emotion: Emotion,
    val count: Int,
    val percent: Float,
)
