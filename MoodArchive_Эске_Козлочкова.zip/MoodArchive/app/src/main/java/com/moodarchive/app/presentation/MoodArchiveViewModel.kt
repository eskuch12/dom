package com.moodarchive.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.moodarchive.app.data.local.SettingsStore
import com.moodarchive.app.data.local.UserSettings
import com.moodarchive.app.domain.model.Coordinates
import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.MediaAttachment
import com.moodarchive.app.domain.model.MediaType
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.domain.model.SyncState
import com.moodarchive.app.domain.repository.MoodEntryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.util.UUID

data class EditorState(
    val entryId: String? = null,
    val text: String = "",
    val emotion: Emotion = Emotion.Calm,
    val attachments: List<MediaAttachment> = emptyList(),
    val includeLocation: Boolean = false,
)

class MoodArchiveViewModel(
    private val repository: MoodEntryRepository,
    private val settingsStore: SettingsStore,
) : ViewModel() {
    val entries: StateFlow<List<MoodEntry>> = repository.observeEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val settings: StateFlow<UserSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    private val _editorState = MutableStateFlow(EditorState())
    val editorState = _editorState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _searchEmotion = MutableStateFlow<Emotion?>(null)
    val searchEmotion = _searchEmotion.asStateFlow()

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate = _selectedDate.asStateFlow()

    private val _selectedMonth = MutableStateFlow(YearMonth.now())
    val selectedMonth = _selectedMonth.asStateFlow()

    private val _exportPreview = MutableStateFlow("")
    val exportPreview = _exportPreview.asStateFlow()

    fun startNewEntry() {
        _editorState.value = EditorState()
    }

    fun editEntry(entry: MoodEntry) {
        _editorState.value = EditorState(
            entryId = entry.id,
            text = entry.text,
            emotion = entry.emotion,
            attachments = entry.attachments,
            includeLocation = entry.location != null,
        )
    }

    fun updateText(value: String) {
        _editorState.value = _editorState.value.copy(text = value)
    }

    fun updateEmotion(value: Emotion) {
        _editorState.value = _editorState.value.copy(emotion = value)
    }

    fun toggleLocation() {
        _editorState.value = _editorState.value.copy(
            includeLocation = !_editorState.value.includeLocation,
        )
    }

    fun addAttachment(type: MediaType) {
        val name = when (type) {
            MediaType.Photo -> "photo-${System.currentTimeMillis()}.jpg"
            MediaType.Video -> "video-${System.currentTimeMillis()}.mp4"
            MediaType.Audio -> "voice-${System.currentTimeMillis()}.m4a"
            MediaType.File -> "document-${System.currentTimeMillis()}.pdf"
        }
        _editorState.value = _editorState.value.copy(
            attachments = _editorState.value.attachments + MediaAttachment(
                id = UUID.randomUUID().toString(),
                type = type,
                localUri = "content://pending/$name",
                displayName = name,
            ),
        )
    }

    fun removeAttachment(id: String) {
        _editorState.value = _editorState.value.copy(
            attachments = _editorState.value.attachments.filterNot { it.id == id },
        )
    }

    fun saveEntry(onSaved: () -> Unit) {
        val state = _editorState.value
        viewModelScope.launch {
            val now = Instant.now()
            val existing = entries.value.firstOrNull { it.id == state.entryId }
            repository.saveEntry(
                MoodEntry(
                    id = state.entryId ?: UUID.randomUUID().toString(),
                    userId = existing?.userId ?: "local-demo-user",
                    text = state.text.trim(),
                    emotion = state.emotion,
                    createdAt = existing?.createdAt ?: now,
                    updatedAt = now,
                    attachments = state.attachments,
                    location = if (state.includeLocation) {
                        existing?.location ?: Coordinates(55.7558, 37.6173, "Текущая геопозиция")
                    } else {
                        null
                    },
                    syncState = SyncState.PendingUpload,
                ),
            )
            _editorState.value = EditorState()
            onSaved()
        }
    }

    fun deleteEntry(id: String, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteEntry(id)
            onDeleted()
        }
    }

    fun syncNow() {
        viewModelScope.launch {
            repository.syncNow()
        }
    }

    fun setSearchQuery(value: String) {
        _searchQuery.value = value
    }

    fun setSearchEmotion(value: Emotion?) {
        _searchEmotion.value = value
    }

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
    }

    fun selectMonth(month: YearMonth) {
        _selectedMonth.value = month
    }

    fun generateMarkdownExport() {
        viewModelScope.launch {
            _exportPreview.value = repository.exportMarkdown(entries.value)
        }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            settingsStore.updateDarkTheme(enabled)
        }
    }

    fun setReminders(enabled: Boolean) {
        viewModelScope.launch {
            settingsStore.updateReminders(enabled)
        }
    }

    fun setPinEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsStore.updatePin(enabled)
        }
    }

    fun setPinCode(pinCode: String) {
        viewModelScope.launch {
            settingsStore.updatePinCode(pinCode)
        }
    }
}

class MoodArchiveViewModelFactory(
    private val repository: MoodEntryRepository,
    private val settingsStore: SettingsStore,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        MoodArchiveViewModel(repository, settingsStore) as T
}
