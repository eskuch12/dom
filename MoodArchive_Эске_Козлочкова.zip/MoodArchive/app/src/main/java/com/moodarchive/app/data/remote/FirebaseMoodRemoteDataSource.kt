package com.moodarchive.app.data.remote

import android.net.Uri
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.moodarchive.app.domain.model.Coordinates
import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.MediaAttachment
import com.moodarchive.app.domain.model.MediaType
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.domain.model.SyncState
import kotlinx.coroutines.tasks.await
import java.time.Instant

class FirebaseMoodRemoteDataSource(
    private val firestoreProvider: () -> FirebaseFirestore = { FirebaseFirestore.getInstance() },
    private val storageProvider: () -> FirebaseStorage = { FirebaseStorage.getInstance() },
) {
    suspend fun uploadEntry(entry: MoodEntry): MoodEntry {
        val firestore = firestoreProvider()
        val storage = storageProvider()
        val uploadedAttachments = entry.attachments.map { attachment ->
            val localUri = attachment.localUri
            if (localUri != null && attachment.remoteUrl == null) {
                val ref = storage.reference
                    .child("users/${entry.userId}/entries/${entry.id}/${attachment.id}-${attachment.displayName}")
                ref.putFile(Uri.parse(localUri)).await()
                attachment.copy(remoteUrl = ref.downloadUrl.await().toString())
            } else {
                attachment
            }
        }
        val uploadedEntry = entry.copy(attachments = uploadedAttachments, syncState = SyncState.Synced)
        firestore.collection("users")
            .document(entry.userId)
            .collection("entries")
            .document(entry.id)
            .set(uploadedEntry.toFirestoreMap())
            .await()
        return uploadedEntry
    }

    suspend fun deleteEntry(userId: String, entryId: String) {
        val firestore = firestoreProvider()
        firestore.collection("users")
            .document(userId)
            .collection("entries")
            .document(entryId)
            .delete()
            .await()
    }

    suspend fun fetchRecentEntries(userId: String, limit: Long = 50): List<MoodEntry> {
        val firestore = firestoreProvider()
        val snapshot = firestore.collection("users")
            .document(userId)
            .collection("entries")
            .orderBy("createdAtEpochMs", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
        return snapshot.documents.mapNotNull { it.data?.toMoodEntry(it.id, userId) }
    }
}

private fun MoodEntry.toFirestoreMap(): Map<String, Any?> =
    mapOf(
        "text" to text,
        "emotion" to emotion.name,
        "createdAtEpochMs" to createdAt.toEpochMilli(),
        "updatedAtEpochMs" to updatedAt.toEpochMilli(),
        "attachments" to attachments.map {
            mapOf(
                "id" to it.id,
                "type" to it.type.name,
                "localUri" to it.localUri,
                "remoteUrl" to it.remoteUrl,
                "mimeType" to it.mimeType,
                "displayName" to it.displayName,
                "sizeBytes" to it.sizeBytes,
                "durationMs" to it.durationMs,
            )
        },
        "location" to location?.let {
            mapOf(
                "latitude" to it.latitude,
                "longitude" to it.longitude,
                "label" to it.label,
            )
        },
    )

@Suppress("UNCHECKED_CAST")
private fun Map<String, Any?>.toMoodEntry(id: String, userId: String): MoodEntry =
    MoodEntry(
        id = id,
        userId = userId,
        text = this["text"] as? String ?: "",
        emotion = Emotion.fromName(this["emotion"] as? String),
        createdAt = Instant.ofEpochMilli(this["createdAtEpochMs"] as? Long ?: 0L),
        updatedAt = Instant.ofEpochMilli(this["updatedAtEpochMs"] as? Long ?: 0L),
        attachments = (this["attachments"] as? List<Map<String, Any?>>).orEmpty().map {
            MediaAttachment(
                id = it["id"] as? String ?: "",
                type = MediaType.valueOf(it["type"] as? String ?: MediaType.File.name),
                localUri = it["localUri"] as? String,
                remoteUrl = it["remoteUrl"] as? String,
                mimeType = it["mimeType"] as? String,
                displayName = it["displayName"] as? String ?: "",
                sizeBytes = it["sizeBytes"] as? Long ?: 0L,
                durationMs = it["durationMs"] as? Long,
            )
        },
        location = (this["location"] as? Map<String, Any?>)?.let {
            Coordinates(
                latitude = it["latitude"] as? Double ?: 0.0,
                longitude = it["longitude"] as? Double ?: 0.0,
                label = it["label"] as? String,
            )
        },
        syncState = SyncState.Synced,
    )
