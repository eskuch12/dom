package com.moodarchive.app

import android.app.Application
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.moodarchive.app.data.sync.MoodSyncWorker
import java.util.concurrent.TimeUnit

class MoodArchiveApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
        enqueueSync()
    }

    private fun enqueueSync() {
        val request = PeriodicWorkRequestBuilder<MoodSyncWorker>(30, TimeUnit.MINUTES)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "mood-entry-sync",
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }
}
