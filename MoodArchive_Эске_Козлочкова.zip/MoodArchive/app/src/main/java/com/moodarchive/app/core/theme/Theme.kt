package com.moodarchive.app.core.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF52656D),
    onPrimary = Color.White,
    secondary = Color(0xFF6FA98A),
    tertiary = Color(0xFFD17A68),
    background = Color(0xFFF8F5F0),
    surface = Color(0xFFFFFBF5),
    surfaceVariant = Color(0xFFE2DDD4),
    onBackground = Color(0xFF252320),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB8CBD4),
    onPrimary = Color(0xFF203138),
    secondary = Color(0xFF9FCDB2),
    tertiary = Color(0xFFE6A194),
    background = Color(0xFF181715),
    surface = Color(0xFF211F1C),
    surfaceVariant = Color(0xFF46413B),
    onBackground = Color(0xFFF1ECE4),
)

@Composable
fun MoodArchiveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MoodArchiveTypography,
        content = content,
    )
}
