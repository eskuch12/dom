package com.moodarchive.app.domain.repository

import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.EmotionStats
import com.moodarchive.app.domain.model.MoodEntry
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.YearMonth

interface MoodEntryRepository {
    fun observeEntries(): Flow<List<MoodEntry>>
    fun observeEntry(id: String): Flow<MoodEntry?>
    fun observeEntriesForDate(date: LocalDate): Flow<List<MoodEntry>>
    fun searchEntries(query: String, emotion: Emotion?, date: LocalDate?): Flow<List<MoodEntry>>
    fun observeStats(month: YearMonth): Flow<List<EmotionStats>>

    suspend fun saveEntry(entry: MoodEntry)
    suspend fun deleteEntry(id: String)
    suspend fun syncNow()
    suspend fun exportMarkdown(entries: List<MoodEntry>): String
}
