package com.moodarchive.app.domain.model

enum class MediaType {
    Photo,
    Video,
    Audio,
    File,
}

data class MediaAttachment(
    val id: String,
    val type: MediaType,
    val localUri: String? = null,
    val remoteUrl: String? = null,
    val mimeType: String? = null,
    val displayName: String = "",
    val sizeBytes: Long = 0L,
    val durationMs: Long? = null,
)
