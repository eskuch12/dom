package com.moodarchive.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mood_entries")
data class MoodEntryEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val text: String,
    val emotion: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    val attachmentsJson: String,
    val latitude: Double?,
    val longitude: Double?,
    val locationLabel: String?,
    val syncState: String,
)
