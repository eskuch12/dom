package com.moodarchive.app.domain.model

import androidx.compose.ui.graphics.Color

enum class Emotion(
    val label: String,
    val color: Color,
) {
    Joy("Радость", Color(0xFFF5B84B)),
    Calm("Спокойствие", Color(0xFF6FA98A)),
    Sadness("Грусть", Color(0xFF6D8FB3)),
    Anxiety("Тревога", Color(0xFFD17A68)),
    Anger("Злость", Color(0xFFC65B5B)),
    Gratitude("Благодарность", Color(0xFF9A7CC2)),
    Tired("Усталость", Color(0xFF8C857D));

    companion object {
        fun fromName(value: String?): Emotion = entries.firstOrNull { it.name == value } ?: Calm
    }
}
