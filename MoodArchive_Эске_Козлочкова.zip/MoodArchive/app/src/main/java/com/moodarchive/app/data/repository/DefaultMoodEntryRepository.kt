﻿package com.moodarchive.app.data.repository

import com.moodarchive.app.data.local.MoodEntryDao
import com.moodarchive.app.data.local.toDomain
import com.moodarchive.app.data.local.toEntity
import com.moodarchive.app.data.remote.FirebaseMoodRemoteDataSource
import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.EmotionStats
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.domain.model.SyncState
import com.moodarchive.app.domain.repository.MoodEntryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.ZoneId
import java.time.YearMonth
import java.time.format.DateTimeFormatter

class DefaultMoodEntryRepository(
    private val dao: MoodEntryDao,
    private val remoteDataSource: FirebaseMoodRemoteDataSource,
    private val userIdProvider: () -> String,
) : MoodEntryRepository {
    private val zoneId: ZoneId = ZoneId.systemDefault()

    override fun observeEntries(): Flow<List<MoodEntry>> =
        dao.observeEntries().map { entries -> entries.map { it.toDomain() } }

    override fun observeEntry(id: String): Flow<MoodEntry?> =
        dao.observeEntry(id).map { it?.toDomain() }

    override fun observeEntriesForDate(date: LocalDate): Flow<List<MoodEntry>> {
        val (start, end) = date.toEpochRange()
        return dao.observeEntriesBetween(start, end).map { entries -> entries.map { it.toDomain() } }
    }

    override fun searchEntries(query: String, emotion: Emotion?, date: LocalDate?): Flow<List<MoodEntry>> {
        val range = date?.toEpochRange()
        return dao.search(
            query = query.trim(),
            emotion = emotion?.name,
            startEpochMs = range?.first,
            endEpochMs = range?.second,
        ).map { entries -> entries.map { it.toDomain() } }
    }

    override fun observeStats(month: YearMonth): Flow<List<EmotionStats>> {
        val start = month.atDay(1)
        val end = month.atEndOfMonth()
        val (startEpoch, _) = start.toEpochRange()
        val (_, endEpoch) = end.toEpochRange()
        return dao.observeEntriesBetween(startEpoch, endEpoch).map { entities ->
            val entries = entities.map { it.toDomain() }
            val total = entries.size.coerceAtLeast(1)
            entries
                .groupingBy { it.emotion }
                .eachCount()
                .map { (emotion, count) ->
                    EmotionStats(emotion = emotion, count = count, percent = count / total.toFloat())
                }
                .sortedByDescending { it.count }
        }
    }

    override suspend fun saveEntry(entry: MoodEntry) {
        dao.upsert(entry.toEntity(syncStateOverride = SyncState.PendingUpload))
    }

    override suspend fun deleteEntry(id: String) {
        val existing = dao.observeEntrySnapshot(id) ?: return
        dao.upsert(existing.copy(syncState = SyncState.PendingDelete.name))
    }

    override suspend fun syncNow() {
        val userId = userIdProvider()
        val pending = dao.pendingSync()
        pending.forEach { entity ->
            val entry = entity.toDomain()
            runCatching {
                if (entry.syncState == SyncState.PendingDelete) {
                    remoteDataSource.deleteEntry(entry.userId, entry.id)
                    dao.deleteById(entry.id)
                } else {
                    val uploaded = remoteDataSource.uploadEntry(entry.copy(userId = userId))
                    dao.upsert(uploaded.toEntity(syncStateOverride = SyncState.Synced))
                }
            }.onFailure {
                dao.updateSyncState(entry.id, SyncState.Failed.name, System.currentTimeMillis())
            }
        }

        runCatching {
            remoteDataSource.fetchRecentEntries(userId)
        }.onSuccess { remoteEntries ->
            dao.upsertAll(remoteEntries.map { it.toEntity(syncStateOverride = SyncState.Synced) })
        }
    }

    override suspend fun exportMarkdown(entries: List<MoodEntry>): String {
        val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(zoneId)
        return buildString {
            appendLine("# MoodArchive")
            appendLine()
            entries.sortedByDescending { it.createdAt }.forEach { entry ->
                appendLine("## ${formatter.format(entry.createdAt)} - ${entry.emotion.label}")
                appendLine()
                appendLine(entry.text.ifBlank { "_Без текстовой заметки_" })
                if (entry.attachments.isNotEmpty()) {
                    appendLine()
                    appendLine("Вложения:")
                    entry.attachments.forEach { attachment ->
                        appendLine("- ${attachment.type}: ${attachment.displayName}")
                    }
                }
                entry.location?.let {
                    appendLine()
                    appendLine("Геолокация: ${it.label ?: "${it.latitude}, ${it.longitude}"}")
                }
                appendLine()
            }
        }
    }

    private fun LocalDate.toEpochRange(): Pair<Long, Long> {
        val start = atStartOfDay(zoneId).toInstant().toEpochMilli()
        val end = plusDays(1).atStartOfDay(zoneId).toInstant().toEpochMilli() - 1
        return start to end
    }
}

private suspend fun MoodEntryDao.observeEntrySnapshot(id: String) =
    observeEntry(id).firstOrNull()
