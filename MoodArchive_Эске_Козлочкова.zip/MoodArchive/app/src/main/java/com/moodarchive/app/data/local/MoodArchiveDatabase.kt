package com.moodarchive.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MoodEntryEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class MoodArchiveDatabase : RoomDatabase() {
    abstract fun moodEntryDao(): MoodEntryDao

    companion object {
        fun create(context: Context): MoodArchiveDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                MoodArchiveDatabase::class.java,
                "moodarchive.db",
            )
                .fallbackToDestructiveMigration()
                .build()
    }
}
