package com.moodarchive.app.core.navigation

sealed class Route(val value: String) {
    data object Splash : Route("splash")
    data object Security : Route("security")
    data object Home : Route("home")
    data object Editor : Route("editor") {
        fun create(entryId: String) = "editor/$entryId"
    }
    data object Detail : Route("entry/{entryId}") {
        fun create(entryId: String) = "entry/$entryId"
    }
    data object Calendar : Route("calendar")
    data object Stats : Route("stats")
    data object Search : Route("search")
    data object Settings : Route("settings")
}
