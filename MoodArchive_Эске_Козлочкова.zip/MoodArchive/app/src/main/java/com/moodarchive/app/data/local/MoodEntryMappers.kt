package com.moodarchive.app.data.local

import com.moodarchive.app.domain.model.Coordinates
import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.MediaAttachment
import com.moodarchive.app.domain.model.MediaType
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.domain.model.SyncState
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

fun MoodEntryEntity.toDomain(): MoodEntry =
    MoodEntry(
        id = id,
        userId = userId,
        text = text,
        emotion = Emotion.fromName(emotion),
        createdAt = Instant.ofEpochMilli(createdAtEpochMs),
        updatedAt = Instant.ofEpochMilli(updatedAtEpochMs),
        attachments = attachmentsJson.toAttachments(),
        location = latitude?.let { lat ->
            Coordinates(
                latitude = lat,
                longitude = longitude ?: 0.0,
                label = locationLabel,
            )
        },
        syncState = SyncState.valueOf(syncState),
    )

fun MoodEntry.toEntity(syncStateOverride: SyncState? = null): MoodEntryEntity =
    MoodEntryEntity(
        id = id,
        userId = userId,
        text = text,
        emotion = emotion.name,
        createdAtEpochMs = createdAt.toEpochMilli(),
        updatedAtEpochMs = updatedAt.toEpochMilli(),
        attachmentsJson = attachments.toJson(),
        latitude = location?.latitude,
        longitude = location?.longitude,
        locationLabel = location?.label,
        syncState = (syncStateOverride ?: syncState).name,
    )

private fun List<MediaAttachment>.toJson(): String {
    val array = JSONArray()
    forEach { attachment ->
        array.put(
            JSONObject()
                .put("id", attachment.id)
                .put("type", attachment.type.name)
                .put("localUri", attachment.localUri)
                .put("remoteUrl", attachment.remoteUrl)
                .put("mimeType", attachment.mimeType)
                .put("displayName", attachment.displayName)
                .put("sizeBytes", attachment.sizeBytes)
                .put("durationMs", attachment.durationMs),
        )
    }
    return array.toString()
}

private fun String.toAttachments(): List<MediaAttachment> {
    if (isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(this)
        buildList {
            repeat(array.length()) { index ->
                val item = array.getJSONObject(index)
                add(
                    MediaAttachment(
                        id = item.optString("id"),
                        type = MediaType.valueOf(item.optString("type", MediaType.File.name)),
                        localUri = item.optString("localUri").ifBlank { null },
                        remoteUrl = item.optString("remoteUrl").ifBlank { null },
                        mimeType = item.optString("mimeType").ifBlank { null },
                        displayName = item.optString("displayName"),
                        sizeBytes = item.optLong("sizeBytes"),
                        durationMs = item.optLong("durationMs").takeIf { it > 0 },
                    ),
                )
            }
        }
    }.getOrDefault(emptyList())
}
