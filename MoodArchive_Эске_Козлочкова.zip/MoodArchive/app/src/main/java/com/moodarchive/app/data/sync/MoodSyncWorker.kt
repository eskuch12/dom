package com.moodarchive.app.data.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.moodarchive.app.ServiceLocator

class MoodSyncWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result =
        runCatching {
            ServiceLocator.repository.syncNow()
        }.fold(
            onSuccess = { Result.success() },
            onFailure = { Result.retry() },
        )
}
