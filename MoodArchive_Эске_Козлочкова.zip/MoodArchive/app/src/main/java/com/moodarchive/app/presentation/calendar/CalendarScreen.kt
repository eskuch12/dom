package com.moodarchive.app.presentation.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moodarchive.app.core.navigation.Route
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.presentation.components.EntryCard
import com.moodarchive.app.presentation.components.MoodBottomBar
import kotlinx.coroutines.flow.StateFlow
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(
    entries: List<MoodEntry>,
    selectedDateFlow: StateFlow<LocalDate>,
    currentRoute: Route,
    onDateChange: (LocalDate) -> Unit,
    onNavigate: (Route) -> Unit,
    onOpen: (MoodEntry) -> Unit,
) {
    val selectedDate by selectedDateFlow.collectAsStateWithLifecycle()
    val selectedMonth = YearMonth.from(selectedDate)
    val entriesByDate = entries.groupBy {
        it.createdAt.atZone(ZoneId.systemDefault()).toLocalDate()
    }
    val dayEntries = entriesByDate[selectedDate].orEmpty().sortedByDescending { it.createdAt }
    val monthLabel = selectedMonth.format(DateTimeFormatter.ofPattern("LLLL yyyy", Locale("ru")))

    Scaffold(
        topBar = { TopAppBar(title = { Text("Календарь") }) },
        bottomBar = { MoodBottomBar(currentRoute, onNavigate) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    IconButton(onClick = { onDateChange(selectedMonth.minusMonths(1).atDay(1)) }) {
                        Icon(Icons.Outlined.ChevronLeft, contentDescription = "Предыдущий месяц")
                    }
                    Text(
                        text = monthLabel.replaceFirstChar { it.titlecase(Locale("ru")) },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                    )
                    IconButton(onClick = { onDateChange(selectedMonth.plusMonths(1).atDay(1)) }) {
                        Icon(Icons.Outlined.ChevronRight, contentDescription = "Следующий месяц")
                    }
                }
            }
            item {
                MonthCalendar(
                    month = selectedMonth,
                    selectedDate = selectedDate,
                    entriesByDate = entriesByDate,
                    onDateChange = onDateChange,
                )
            }
            item {
                Text(
                    text = selectedDate.format(DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale("ru"))),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = "Записей: ${dayEntries.size}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
            if (dayEntries.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Text(
                            text = "На выбранный день записей нет",
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                items(dayEntries, key = { it.id }) { entry ->
                    EntryCard(entry = entry, onClick = { onOpen(entry) })
                }
            }
        }
    }
}

@Composable
private fun MonthCalendar(
    month: YearMonth,
    selectedDate: LocalDate,
    entriesByDate: Map<LocalDate, List<MoodEntry>>,
    onDateChange: (LocalDate) -> Unit,
) {
    val firstDay = month.atDay(1)
    val leadingEmptyCells = firstDay.dayOfWeek.value - DayOfWeek.MONDAY.value
    val calendarCells = buildList<LocalDate?> {
        repeat(leadingEmptyCells) { add(null) }
        repeat(month.lengthOfMonth()) { add(month.atDay(it + 1)) }
        while (size % 7 != 0) add(null)
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth()) {
            DayOfWeek.entries.forEach { dayOfWeek ->
                Text(
                    text = dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("ru")),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        calendarCells.chunked(7).forEach { week ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                week.forEach { date ->
                    if (date == null) {
                        Spacer(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f),
                        )
                    } else {
                        DayCell(
                            date = date,
                            selected = date == selectedDate,
                            today = date == LocalDate.now(),
                            entries = entriesByDate[date].orEmpty(),
                            onClick = { onDateChange(date) },
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f),
                        )
                    }
                }
            }
        }
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun DayCell(
    date: LocalDate,
    selected: Boolean,
    today: Boolean,
    entries: List<MoodEntry>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val background = when {
        selected -> MaterialTheme.colorScheme.primary
        entries.isNotEmpty() -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    val contentColor = when {
        selected -> MaterialTheme.colorScheme.onPrimary
        entries.isNotEmpty() -> MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.onSurface
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(4.dp),
    ) {
        Text(
            text = date.dayOfMonth.toString(),
            color = contentColor,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (today || selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.align(Alignment.TopCenter),
        )
        if (entries.isNotEmpty()) {
            FlowRow(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                maxItemsInEachRow = 3,
            ) {
                entries.take(6).forEach { entry ->
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(if (selected) Color.White else entry.emotion.color),
                    )
                }
            }
        }
    }
}
