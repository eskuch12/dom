package com.moodarchive.app.core.theme

import androidx.compose.material3.Typography

val MoodArchiveTypography = Typography()
