package com.moodarchive.app.presentation.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moodarchive.app.core.navigation.Route
import com.moodarchive.app.data.local.UserSettings
import com.moodarchive.app.presentation.components.MoodBottomBar
import kotlinx.coroutines.flow.StateFlow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    exportPreviewFlow: StateFlow<String>,
    settingsFlow: StateFlow<UserSettings>,
    currentRoute: Route,
    onNavigate: (Route) -> Unit,
    onSync: () -> Unit,
    onExport: () -> Unit,
    onDarkThemeChange: (Boolean) -> Unit,
    onRemindersChange: (Boolean) -> Unit,
    onPinChange: (Boolean) -> Unit,
) {
    val exportPreview by exportPreviewFlow.collectAsStateWithLifecycle()
    val settings by settingsFlow.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Настройки") }) },
        bottomBar = { MoodBottomBar(currentRoute, onNavigate) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            SettingSwitch("Темная тема", settings.darkTheme, onDarkThemeChange)
            SettingSwitch("Напоминания о дневнике", settings.reminders, onRemindersChange)
            SettingSwitch("PIN / биометрия", settings.pinEnabled, onPinChange)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onSync) {
                    Icon(Icons.Outlined.Sync, contentDescription = null)
                    Text("Синхронизировать")
                }
                Button(onClick = onExport) {
                    Icon(Icons.Outlined.FileDownload, contentDescription = null)
                    Text("Markdown")
                }
            }

            if (exportPreview.isNotBlank()) {
                Text("Предпросмотр экспорта", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = exportPreview.take(3_000),
                    onValueChange = { },
                    readOnly = true,
                    minLines = 8,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
