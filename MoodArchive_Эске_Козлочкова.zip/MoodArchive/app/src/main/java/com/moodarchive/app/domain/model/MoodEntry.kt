package com.moodarchive.app.domain.model

import java.time.Instant

data class Coordinates(
    val latitude: Double,
    val longitude: Double,
    val label: String? = null,
)

enum class SyncState {
    Synced,
    PendingUpload,
    PendingDelete,
    Failed,
}

data class MoodEntry(
    val id: String,
    val userId: String,
    val text: String,
    val emotion: Emotion,
    val createdAt: Instant,
    val updatedAt: Instant,
    val attachments: List<MediaAttachment> = emptyList(),
    val location: Coordinates? = null,
    val syncState: SyncState = SyncState.PendingUpload,
)
