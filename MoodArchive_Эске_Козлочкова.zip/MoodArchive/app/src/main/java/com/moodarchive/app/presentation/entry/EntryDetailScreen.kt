package com.moodarchive.app.presentation.entry

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.moodarchive.app.domain.model.MoodEntry
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntryDetailScreen(
    entry: MoodEntry?,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Просмотр записи") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Редактировать")
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Удалить")
                    }
                },
            )
        },
    ) { padding ->
        if (entry == null) {
            Text("Запись не найдена", modifier = Modifier.padding(padding).padding(24.dp))
            return@Scaffold
        }
        val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault())
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                AssistChip(onClick = { }, label = { Text(entry.emotion.label) })
                AssistChip(onClick = { }, label = { Text(entry.syncState.name) })
            }
            Text(formatter.format(entry.createdAt), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(entry.text.ifBlank { "Без текстовой заметки" }, style = MaterialTheme.typography.bodyLarge)
            if (entry.attachments.isNotEmpty()) {
                Text("Вложения", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                entry.attachments.forEach { attachment ->
                    AssistChip(onClick = { }, label = { Text("${attachment.type}: ${attachment.displayName}") })
                }
            }
            entry.location?.let {
                Text("Геолокация: ${it.label ?: "${it.latitude}, ${it.longitude}"}")
            }
        }
    }
}
