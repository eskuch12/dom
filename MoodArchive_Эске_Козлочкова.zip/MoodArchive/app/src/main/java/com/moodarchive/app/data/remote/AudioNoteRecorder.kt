package com.moodarchive.app.data.remote

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

class AudioNoteRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null

    fun start(fileName: String = "voice-${System.currentTimeMillis()}.m4a"): File {
        val output = File(context.cacheDir, fileName)
        recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(96_000)
            setAudioSamplingRate(44_100)
            setOutputFile(output.absolutePath)
            prepare()
            start()
        }
        return output
    }

    fun amplitude(): Int = recorder?.maxAmplitude ?: 0

    fun stop() {
        runCatching {
            recorder?.stop()
            recorder?.release()
        }
        recorder = null
    }
}
