package com.moodarchive.app.domain.usecase

import com.moodarchive.app.domain.model.Emotion
import com.moodarchive.app.domain.model.MoodEntry
import com.moodarchive.app.domain.repository.MoodEntryRepository
import java.time.LocalDate
import java.time.YearMonth

class ObserveEntriesUseCase(private val repository: MoodEntryRepository) {
    operator fun invoke() = repository.observeEntries()
}

class ObserveEntryUseCase(private val repository: MoodEntryRepository) {
    operator fun invoke(id: String) = repository.observeEntry(id)
}

class SearchEntriesUseCase(private val repository: MoodEntryRepository) {
    operator fun invoke(query: String, emotion: Emotion?, date: LocalDate?) =
        repository.searchEntries(query, emotion, date)
}

class ObserveCalendarDayUseCase(private val repository: MoodEntryRepository) {
    operator fun invoke(date: LocalDate) = repository.observeEntriesForDate(date)
}

class ObserveEmotionStatsUseCase(private val repository: MoodEntryRepository) {
    operator fun invoke(month: YearMonth) = repository.observeStats(month)
}

class SaveEntryUseCase(private val repository: MoodEntryRepository) {
    suspend operator fun invoke(entry: MoodEntry) = repository.saveEntry(entry)
}

class DeleteEntryUseCase(private val repository: MoodEntryRepository) {
    suspend operator fun invoke(id: String) = repository.deleteEntry(id)
}

class SyncEntriesUseCase(private val repository: MoodEntryRepository) {
    suspend operator fun invoke() = repository.syncNow()
}

class ExportMarkdownUseCase(private val repository: MoodEntryRepository) {
    suspend operator fun invoke(entries: List<MoodEntry>) = repository.exportMarkdown(entries)
}
