package com.moodarchive.app

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.moodarchive.app.data.local.MoodArchiveDatabase
import com.moodarchive.app.data.local.SettingsStore
import com.moodarchive.app.data.remote.FirebaseMoodRemoteDataSource
import com.moodarchive.app.data.repository.DefaultMoodEntryRepository
import com.moodarchive.app.domain.repository.MoodEntryRepository

object ServiceLocator {
    private lateinit var appContext: Context

    val repository: MoodEntryRepository by lazy {
        val database = MoodArchiveDatabase.create(appContext)
        DefaultMoodEntryRepository(
            dao = database.moodEntryDao(),
            remoteDataSource = FirebaseMoodRemoteDataSource(),
            userIdProvider = {
                runCatching { FirebaseAuth.getInstance().currentUser?.uid }
                    .getOrNull()
                    ?: "local-demo-user"
            },
        )
    }

    val settingsStore: SettingsStore by lazy {
        SettingsStore(appContext)
    }

    fun init(context: Context) {
        appContext = context.applicationContext
    }
}
