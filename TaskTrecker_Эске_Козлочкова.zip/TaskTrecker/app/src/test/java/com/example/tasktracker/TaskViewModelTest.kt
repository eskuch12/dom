package com.example.tasktracker

import com.example.tasktracker.data.local.dao.CategoryCount
import com.example.tasktracker.data.local.entity.TaskEntity
import com.example.tasktracker.domain.repository.TaskRepository
import com.example.tasktracker.presentation.TaskViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class TaskViewModelTest {

    private val dispatcher = StandardTestDispatcher()
    private lateinit var repository: FakeTaskRepository
    private lateinit var viewModel: TaskViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        repository = FakeTaskRepository()
        viewModel = TaskViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun addTask_placesTaskInActiveListWithAllInputFields() = runTest(dispatcher) {
        val task = task(
            title = "Сдать отчет",
            description = "PDF и CSV",
            category = "Учеба",
            priority = "HIGH",
            repeatType = "WEEKLY",
            notificationsEnabled = false
        )

        viewModel.addTask(task)
        advanceUntilIdle()

        val added = viewModel.tasks.value.single()
        assertEquals("Сдать отчет", added.title)
        assertEquals("PDF и CSV", added.description)
        assertEquals("Учеба", added.category)
        assertEquals("HIGH", added.priority)
        assertEquals("WEEKLY", added.repeatType)
        assertEquals(false, added.notificationsEnabled)
    }

    @Test
    fun completeTask_movesTaskToArchiveAndAddsGamificationPoints() = runTest(dispatcher) {
        viewModel.addTask(task(title = "Оплатить счета", category = "Дом"))
        advanceUntilIdle()

        val taskId = viewModel.tasks.value.single().id
        viewModel.completeTask(taskId)
        viewModel.loadArchive()
        advanceUntilIdle()

        assertTrue(viewModel.tasks.value.isEmpty())
        assertEquals("Оплатить счета", viewModel.archive.value.single().title)
        assertEquals(10, viewModel.points.value)
        assertEquals(1, viewModel.level.value)
    }

    @Test
    fun loadStats_countsActiveCompletedAndCategories() = runTest(dispatcher) {
        viewModel.addTask(task(title = "Рабочий звонок", category = "Работа"))
        viewModel.addTask(task(title = "Домашнее чтение", category = "Учеба"))
        advanceUntilIdle()

        viewModel.completeTask(viewModel.tasks.value.first().id)
        viewModel.loadStats()
        advanceUntilIdle()

        assertEquals(1, viewModel.completedCount.value)
        assertEquals(1, viewModel.activeCount.value)
        assertEquals(
            listOf(CategoryCount("Работа", 1), CategoryCount("Учеба", 1)),
            viewModel.categories.value.sortedBy { it.category }
        )
    }

    @Test
    fun repeatedCompletionsIncreaseLevelEveryHundredPoints() = runTest(dispatcher) {
        repeat(10) { index ->
            viewModel.addTask(task(title = "Задача $index"))
            advanceUntilIdle()
            viewModel.completeTask(viewModel.tasks.value.single().id)
            advanceUntilIdle()
        }

        assertEquals(100, viewModel.points.value)
        assertEquals(2, viewModel.level.value)
    }

    private fun task(
        title: String,
        description: String? = null,
        category: String = "Дом",
        priority: String = "MEDIUM",
        dateTime: Long = 1_800_000_000_000,
        repeatType: String = "NONE",
        notificationsEnabled: Boolean = true
    ) = TaskEntity(
        title = title,
        description = description,
        category = category,
        priority = priority,
        dateTime = dateTime,
        isCompleted = false,
        reminderTime = dateTime - 600_000,
        repeatType = repeatType,
        notificationsEnabled = notificationsEnabled
    )
}

private class FakeTaskRepository : TaskRepository {
    private val tasks = mutableListOf<TaskEntity>()
    private var nextId = 1

    override suspend fun getActiveTasks(): List<TaskEntity> =
        tasks.filter { !it.isCompleted }.sortedBy { it.dateTime }

    override suspend fun getCompletedTasks(): List<TaskEntity> =
        tasks.filter { it.isCompleted }.sortedByDescending { it.dateTime }

    override suspend fun insert(task: TaskEntity) {
        val taskToInsert = if (task.id == 0) task.copy(id = nextId++) else task
        tasks.removeAll { it.id == taskToInsert.id }
        tasks.add(taskToInsert)
    }

    override suspend fun markCompleted(id: Int) {
        replace(id) { it.copy(isCompleted = true) }
    }

    override suspend fun restoreTask(id: Int) {
        replace(id) { it.copy(isCompleted = false) }
    }

    override suspend fun getCompletedCount(): Int =
        tasks.count { it.isCompleted }

    override suspend fun getActiveCount(): Int =
        tasks.count { !it.isCompleted }

    override suspend fun getTasksByCategory(): List<CategoryCount> =
        tasks.groupingBy { it.category }
            .eachCount()
            .map { CategoryCount(it.key, it.value) }

    private fun replace(id: Int, transform: (TaskEntity) -> TaskEntity) {
        val index = tasks.indexOfFirst { it.id == id }
        if (index >= 0) {
            tasks[index] = transform(tasks[index])
        }
    }
}
