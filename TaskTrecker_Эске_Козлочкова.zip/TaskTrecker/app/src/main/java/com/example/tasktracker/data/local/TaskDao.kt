package com.example.tasktracker.data.local.dao

import androidx.room.*
import com.example.tasktracker.data.local.entity.TaskEntity

@Dao
interface TaskDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: TaskEntity): Long

    @Update
    suspend fun update(task: TaskEntity)

    @Delete
    suspend fun delete(task: TaskEntity)

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY dateTime ASC")
    suspend fun getActiveTasks(): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE isCompleted = 1 ORDER BY dateTime DESC")
    suspend fun getCompletedTasks(): List<TaskEntity>

    @Query("UPDATE tasks SET isCompleted = 1 WHERE id = :taskId")
    suspend fun markCompleted(taskId: Int)

    @Query("UPDATE tasks SET isCompleted = 0 WHERE id = :taskId")
    suspend fun restoreTask(taskId: Int)

    @Query("SELECT COUNT(*) FROM tasks WHERE isCompleted = 1")
    suspend fun getCompletedCount(): Int

    @Query("SELECT COUNT(*) FROM tasks WHERE isCompleted = 0")
    suspend fun getActiveCount(): Int

    @Query("SELECT category, COUNT(*) as count FROM tasks GROUP BY category")
    suspend fun getTasksByCategory(): List<CategoryCount>
}