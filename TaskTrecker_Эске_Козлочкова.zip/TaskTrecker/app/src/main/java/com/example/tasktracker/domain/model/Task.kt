package com.example.tasktracker.domain.model

data class Task(
    val id: Int = 0,
    val title: String,
    val description: String?,
    val category: String,
    val priority: String,
    val dateTime: Long,
    val isCompleted: Boolean = false
)