package com.example.tasktracker.ui

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.tasktracker.data.local.TaskDatabase
import com.example.tasktracker.data.local.dao.CategoryCount
import com.example.tasktracker.data.local.entity.TaskEntity
import com.example.tasktracker.data.repository.TaskRepositoryImpl
import com.example.tasktracker.presentation.TaskViewModel
import com.example.tasktracker.utils.ExportUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    private val viewModel: TaskViewModel by viewModels {
        val dao = TaskDatabase.getDatabase(this).taskDao()
        val repo = TaskRepositoryImpl(dao, this)
        TaskViewModelFactory(repo)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            var tab by remember { mutableStateOf(0) }
            var darkTheme by remember { mutableStateOf(false) }

            MaterialTheme(colorScheme = if (darkTheme) darkColorScheme() else lightColorScheme()) {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("TaskTracker") },
                            actions = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(end = 12.dp)
                                ) {
                                    Text("Темная")
                                    Switch(checked = darkTheme, onCheckedChange = { darkTheme = it })
                                }
                            }
                        )
                    }
                ) { padding ->
                    Column(Modifier.padding(padding)) {
                        TabRow(selectedTabIndex = tab) {
                            listOf("Задачи", "Архив", "Статистика", "Календарь", "Прогресс")
                                .forEachIndexed { index, title ->
                                    Tab(selected = tab == index, onClick = { tab = index }) {
                                        Text(title, modifier = Modifier.padding(12.dp))
                                    }
                                }
                        }

                        when (tab) {
                            0 -> TaskScreen(viewModel)
                            1 -> ArchiveScreen(viewModel)
                            2 -> StatsScreen(viewModel)
                            3 -> CalendarScreen(viewModel)
                            4 -> ProgressScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TaskScreen(viewModel: TaskViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Дом") }
    var priority by remember { mutableStateOf("MEDIUM") }
    var dateTime by remember { mutableStateOf(System.currentTimeMillis()) }
    var repeatType by remember { mutableStateOf("NONE") }
    var reminderOffset by remember { mutableStateOf(5 * 60 * 1000L) }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { viewModel.loadTasks() }

    val visibleTasks = tasks.filter {
        search.isBlank() ||
            it.title.contains(search, ignoreCase = true) ||
            (it.description?.contains(search, ignoreCase = true) == true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Название задачи") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Описание") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { ChipRow("Категория", listOf("Дом", "Работа", "Учеба"), category) { category = it } }
        item { ChipRow("Приоритет", listOf("LOW", "MEDIUM", "HIGH"), priority) { priority = it } }
        item { ChipRow("Повтор", listOf("NONE", "DAILY", "WEEKLY"), repeatType) { repeatType = it } }
        item {
            Text("Напоминание")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                mapOf(
                    "5 мин" to 5 * 60 * 1000L,
                    "1 час" to 60 * 60 * 1000L,
                    "1 день" to 24 * 60 * 60 * 1000L
                ).forEach { (label, value) ->
                    FilterChip(
                        selected = notificationsEnabled && reminderOffset == value,
                        onClick = {
                            notificationsEnabled = true
                            reminderOffset = value
                        },
                        label = { Text(label) }
                    )
                }
                FilterChip(
                    selected = !notificationsEnabled,
                    onClick = { notificationsEnabled = false },
                    label = { Text("Выкл") }
                )
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val cal = Calendar.getInstance()
                    DatePickerDialog(
                        context,
                        { _, y, m, d ->
                            val selected = Calendar.getInstance().apply { timeInMillis = dateTime }
                            selected.set(y, m, d)
                            dateTime = selected.timeInMillis
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }) { Text("Дата") }

                Button(onClick = {
                    val cal = Calendar.getInstance()
                    TimePickerDialog(
                        context,
                        { _, h, min ->
                            val selected = Calendar.getInstance().apply { timeInMillis = dateTime }
                            selected.set(Calendar.HOUR_OF_DAY, h)
                            selected.set(Calendar.MINUTE, min)
                            dateTime = selected.timeInMillis
                        },
                        cal.get(Calendar.HOUR_OF_DAY),
                        cal.get(Calendar.MINUTE),
                        true
                    ).show()
                }) { Text("Время") }

                Text(
                    dateFormat.format(dateTime),
                    modifier = Modifier.align(Alignment.CenterVertically)
                )
            }
        }
        item {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        viewModel.addTask(
                            TaskEntity(
                                title = title.trim(),
                                description = description.trim().ifBlank { null },
                                category = category,
                                priority = priority,
                                dateTime = dateTime,
                                isCompleted = false,
                                reminderTime = if (notificationsEnabled) dateTime - reminderOffset else null,
                                repeatType = repeatType,
                                notificationsEnabled = notificationsEnabled
                            )
                        )
                        title = ""
                        description = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Добавить")
            }
        }
        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                label = { Text("Поиск") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        items(visibleTasks, key = { it.id }) { task ->
            TaskCard(task = task, actionText = "Выполнено") {
                viewModel.completeTask(task.id)
            }
        }
    }
}

@Composable
fun ArchiveScreen(viewModel: TaskViewModel) {
    val archive by viewModel.archive.collectAsState()
    var categoryFilter by remember { mutableStateOf("Все") }
    var priorityFilter by remember { mutableStateOf("Все") }

    LaunchedEffect(Unit) { viewModel.loadArchive() }

    val filtered = archive.filter {
        (categoryFilter == "Все" || it.category == categoryFilter) &&
            (priorityFilter == "Все" || it.priority == priorityFilter)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { ChipRow("Категория", listOf("Все", "Дом", "Работа", "Учеба"), categoryFilter) { categoryFilter = it } }
        item { ChipRow("Приоритет", listOf("Все", "LOW", "MEDIUM", "HIGH"), priorityFilter) { priorityFilter = it } }
        items(filtered, key = { it.id }) { task ->
            TaskCard(task = task, actionText = "Восстановить") {
                viewModel.restoreTask(task.id)
            }
        }
    }
}

@Composable
fun StatsScreen(viewModel: TaskViewModel) {
    val completed by viewModel.completedCount.collectAsState()
    val active by viewModel.activeCount.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(Unit) { viewModel.loadStats() }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Выполнено: $completed")
        Text("Активные: $active")
        TaskPieChart(completed, active)
        CategoryPieChart(categories)
        Button(onClick = { ExportUtils.exportAndShare(context, completed, active, categories) }) {
            Text("Экспорт CSV")
        }
    }
}

@Composable
fun CalendarScreen(viewModel: TaskViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    var selectedDate by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) { viewModel.loadTasks() }

    val selectedDateFormat = remember { SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()) }
    val taskTimeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val calendar = Calendar.getInstance().apply { timeInMillis = selectedDate }
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    val firstDay = Calendar.getInstance().apply {
        clear()
        set(year, month, 1)
    }
    val daysInMonth = firstDay.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = (firstDay.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val days = buildList {
        repeat(firstDayOfWeek) { add(null) }
        for (day in 1..daysInMonth) add(day)
    }
    val selectedTasks = tasks
        .filter { isSameDay(it.dateTime, selectedDate) }
        .sortedBy { it.dateTime }

    fun moveMonth(delta: Int) {
        val next = Calendar.getInstance().apply {
            timeInMillis = selectedDate
            add(Calendar.MONTH, delta)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        selectedDate = next.timeInMillis
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = { moveMonth(-1) }) { Text("<") }
                Text("${month + 1} / $year", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { moveMonth(1) }) { Text(">") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс").forEach {
                    Text(it, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item {
            LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.height(320.dp)) {
                items(days) { day ->
                    if (day == null) {
                        Spacer(Modifier.aspectRatio(1f))
                    } else {
                        val dayTime = Calendar.getInstance().apply {
                            clear()
                            set(year, month, day, 12, 0)
                        }.timeInMillis
                        val taskCount = tasks.count { isSameDay(it.dateTime, dayTime) }
                        val selected = isSameDay(dayTime, selectedDate)
                        val background = when {
                            selected -> MaterialTheme.colorScheme.primary
                            taskCount > 0 -> MaterialTheme.colorScheme.secondaryContainer
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                        val textColor = when {
                            selected -> MaterialTheme.colorScheme.onPrimary
                            taskCount > 0 -> MaterialTheme.colorScheme.onSecondaryContainer
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }

                        Box(
                            modifier = Modifier
                                .padding(4.dp)
                                .aspectRatio(1f)
                                .background(background, RoundedCornerShape(8.dp))
                                .clickable { selectedDate = dayTime },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(day.toString(), color = textColor)
                                if (taskCount > 0) {
                                    Text("$taskCount", color = textColor, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Задачи на ${selectedDateFormat.format(selectedDate)}: ${selectedTasks.size}",
                style = MaterialTheme.typography.titleMedium
            )
        }
        if (selectedTasks.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Text(
                        "На выбранный день задач нет. Выберите дату с числом внутри ячейки или добавьте задачу на этот день.",
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(selectedTasks, key = { it.id }) { task ->
                TaskCard(
                    task = task.copy(
                        description = listOfNotNull(
                            task.description,
                            "Время: ${taskTimeFormat.format(task.dateTime)}"
                        ).joinToString("\n")
                    ),
                    actionText = "Выполнено"
                ) {
                    viewModel.completeTask(task.id)
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(viewModel: TaskViewModel) {
    val points by viewModel.points.collectAsState()
    val level by viewModel.level.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Уровень $level", style = MaterialTheme.typography.titleLarge)
        LinearProgressIndicator(progress = { (points % 100) / 100f }, modifier = Modifier.fillMaxWidth())
        Text("Очки: $points")
    }
}

@Composable
private fun TaskCard(task: TaskEntity, actionText: String, onAction: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(task.title, style = MaterialTheme.typography.titleMedium)
                task.description?.let { Text(it) }
                Text("${task.category} · ${task.priority}")
            }
            Button(onClick = onAction) { Text(actionText) }
        }
    }
}

@Composable
private fun ChipRow(title: String, values: List<String>, selected: String, onSelect: (String) -> Unit) {
    Text(title)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        values.forEach {
            FilterChip(selected = selected == it, onClick = { onSelect(it) }, label = { Text(it) })
        }
    }
}

@Composable
fun CategoryPieChart(categories: List<CategoryCount>) {
    val total = categories.sumOf { it.count }
    if (total == 0) return

    val colors = listOf(
        Color(0xFF3366CC),
        Color(0xFFDC3912),
        Color(0xFFFF9900),
        Color(0xFF109618)
    )

    Canvas(modifier = Modifier.size(200.dp)) {
        var startAngle = 0f
        categories.forEachIndexed { index, item ->
            val sweep = 360f * item.count / total
            drawArc(
                color = colors[index % colors.size],
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = true
            )
            startAngle += sweep
        }
    }
}

@Composable
fun TaskPieChart(completed: Int, active: Int) {
    val total = completed + active
    if (total == 0) return

    Canvas(modifier = Modifier.size(200.dp)) {
        val completedAngle = 360f * completed / total
        drawArc(Color(0xFF2E7D32), 0f, completedAngle, useCenter = true)
        drawArc(Color(0xFFC62828), completedAngle, 360f - completedAngle, useCenter = true)
    }
}

fun isSameDay(time1: Long, time2: Long): Boolean {
    val c1 = Calendar.getInstance().apply { timeInMillis = time1 }
    val c2 = Calendar.getInstance().apply { timeInMillis = time2 }
    return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) &&
        c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
}
