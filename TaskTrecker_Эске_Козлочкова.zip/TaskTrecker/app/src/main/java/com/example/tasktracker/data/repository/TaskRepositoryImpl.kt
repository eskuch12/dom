package com.example.tasktracker.data.repository

import android.content.Context
import com.example.tasktracker.data.local.dao.TaskDao
import com.example.tasktracker.data.local.entity.TaskEntity
import com.example.tasktracker.data.local.dao.CategoryCount
import com.example.tasktracker.domain.repository.TaskRepository
import com.example.tasktracker.notifications.NotificationScheduler

class TaskRepositoryImpl(
    private val dao: TaskDao,
    private val context: Context
) : TaskRepository {

    override suspend fun getActiveTasks(): List<TaskEntity> {
        return dao.getActiveTasks()
    }

    override suspend fun getCompletedTasks(): List<TaskEntity> {
        return dao.getCompletedTasks()
    }

    override suspend fun insert(task: TaskEntity) {
        val id = dao.insert(task).toInt()
        val newTask = task.copy(id = id)
        NotificationScheduler.schedule(context, newTask)
    }

    override suspend fun markCompleted(id: Int) {
        dao.markCompleted(id)
        NotificationScheduler.cancel(context, id)
    }

    override suspend fun restoreTask(id: Int) {
        dao.restoreTask(id)
    }

    override suspend fun getCompletedCount(): Int {
        return dao.getCompletedCount()
    }

    override suspend fun getActiveCount(): Int {
        return dao.getActiveCount()
    }

    override suspend fun getTasksByCategory(): List<CategoryCount> {
        return dao.getTasksByCategory()
    }
}