package com.example.tasktracker.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tasktracker.data.local.entity.TaskEntity
import com.example.tasktracker.domain.repository.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class TaskViewModel(
    private val repository: TaskRepository
) : ViewModel() {

    private val _tasks = MutableStateFlow<List<TaskEntity>>(emptyList())
    val tasks: StateFlow<List<TaskEntity>> = _tasks

    private val _archive = MutableStateFlow<List<TaskEntity>>(emptyList())
    val archive: StateFlow<List<TaskEntity>> = _archive

    private val _completedCount = MutableStateFlow(0)
    val completedCount: StateFlow<Int> = _completedCount

    private val _activeCount = MutableStateFlow(0)
    val activeCount: StateFlow<Int> = _activeCount

    private val _categories = MutableStateFlow(emptyList<com.example.tasktracker.data.local.dao.CategoryCount>())
    val categories: StateFlow<List<com.example.tasktracker.data.local.dao.CategoryCount>> = _categories

    private val _points = MutableStateFlow(0)
    val points: StateFlow<Int> = _points

    private val _level = MutableStateFlow(1)
    val level: StateFlow<Int> = _level

    fun loadTasks() {
        viewModelScope.launch {
            _tasks.value = repository.getActiveTasks()
        }
    }

    fun loadArchive() {
        viewModelScope.launch {
            _archive.value = repository.getCompletedTasks()
        }
    }

    fun loadStats() {
        viewModelScope.launch {
            _completedCount.value = repository.getCompletedCount()
            _activeCount.value = repository.getActiveCount()
            _categories.value = repository.getTasksByCategory()
        }
    }

    fun addTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.insert(task)
            loadTasks()
        }
    }

    fun completeTask(taskId: Int) {
        viewModelScope.launch {
            repository.markCompleted(taskId)
            addPoints(10)
            loadTasks()
            loadStats()
        }
    }

    fun restoreTask(taskId: Int) {
        viewModelScope.launch {
            repository.restoreTask(taskId)
            loadTasks()
            loadArchive()
            loadStats()
        }
    }

    private fun addPoints(value: Int) {
        val newPoints = _points.value + value
        _points.value = newPoints
        _level.value = newPoints / 100 + 1
    }
}
