package com.example.tasktracker.notifications

import android.content.Context
import androidx.work.*
import com.example.tasktracker.data.local.entity.TaskEntity
import java.util.concurrent.TimeUnit

object NotificationScheduler {

    fun schedule(context: Context, task: TaskEntity) {

        if (!task.notificationsEnabled) return

        val reminderTime = task.reminderTime ?: return
        val delay = reminderTime - System.currentTimeMillis()
        if (delay <= 0) return

        val data = workDataOf(
            "title" to task.title,
            "taskId" to task.id,
            "repeatType" to task.repeatType
        )

        val request = OneTimeWorkRequestBuilder<TaskReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "task_${task.id}",
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    fun cancel(context: Context, taskId: Int) {
        WorkManager.getInstance(context).cancelUniqueWork("task_$taskId")
    }
}