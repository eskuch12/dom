package com.example.tasktracker.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.tasktracker.data.local.TaskDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class TaskReminderWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val title = inputData.getString("title") ?: "Задача"
        val taskId = inputData.getInt("taskId", 0)
        val repeatType = inputData.getString("repeatType")

        val manager =
            applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId = "task_channel"
        val channel = NotificationChannel(
            channelId,
            "Задачи",
            NotificationManager.IMPORTANCE_HIGH
        )
        manager.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("Напоминание")
            .setContentText(title)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
            .build()

        manager.notify(taskId, notification)

        if (repeatType == "DAILY" || repeatType == "WEEKLY") {
            createNextTask(taskId, repeatType)
        }

        return Result.success()
    }

    private suspend fun createNextTask(taskId: Int, repeatType: String?) {
        val dao = TaskDatabase.getDatabase(applicationContext).taskDao()
        val tasks = withContext(Dispatchers.IO) {
            dao.getActiveTasks()
        }
        val task = tasks.find { it.id == taskId } ?: return

        val nextTime = when (repeatType) {
            "DAILY" -> task.dateTime + TimeUnit.DAYS.toMillis(1)
            "WEEKLY" -> task.dateTime + TimeUnit.DAYS.toMillis(7)
            else -> return
        }

        val newTask = task.copy(
            id = 0,
            dateTime = nextTime,
            reminderTime = task.reminderTime?.let {
                it + (nextTime - task.dateTime)
            },
            isCompleted = false
        )

        val newId = withContext(Dispatchers.IO) {
            dao.insert(newTask).toInt()
        }

        val data = workDataOf(
            "title" to newTask.title,
            "taskId" to newId,
            "repeatType" to newTask.repeatType
        )
        val delay = newTask.reminderTime?.minus(System.currentTimeMillis()) ?: return
        if (delay <= 0) return

        val request = OneTimeWorkRequestBuilder<TaskReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()

        WorkManager.getInstance(applicationContext).enqueueUniqueWork(
            "task_$newId",
            ExistingWorkPolicy.REPLACE,
            request
        )
    }
}
