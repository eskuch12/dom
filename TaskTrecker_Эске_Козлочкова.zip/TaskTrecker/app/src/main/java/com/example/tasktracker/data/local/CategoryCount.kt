package com.example.tasktracker.data.local.dao

data class CategoryCount(
    val category: String,
    val count: Int
)