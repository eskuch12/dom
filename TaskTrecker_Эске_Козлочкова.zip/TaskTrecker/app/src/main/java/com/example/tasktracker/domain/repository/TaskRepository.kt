package com.example.tasktracker.domain.repository

import com.example.tasktracker.data.local.entity.TaskEntity
import com.example.tasktracker.data.local.dao.CategoryCount

interface TaskRepository {

    suspend fun getActiveTasks(): List<TaskEntity>

    suspend fun getCompletedTasks(): List<TaskEntity>

    suspend fun insert(task: TaskEntity)

    suspend fun markCompleted(id: Int)

    suspend fun restoreTask(id: Int)

    suspend fun getCompletedCount(): Int

    suspend fun getActiveCount(): Int

    suspend fun getTasksByCategory(): List<CategoryCount>
}