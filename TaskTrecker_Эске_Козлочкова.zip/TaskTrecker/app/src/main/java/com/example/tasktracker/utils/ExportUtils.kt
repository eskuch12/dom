package com.example.tasktracker.utils

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.tasktracker.data.local.dao.CategoryCount
import java.io.File
import java.io.FileWriter

object ExportUtils {

    fun exportAndShare(
        context: Context,
        completed: Int,
        active: Int,
        categories: List<CategoryCount>
    ) {
        val file = File(context.getExternalFilesDir(null), "task_stats.csv")
        FileWriter(file).use { writer ->
            writer.append("Тип,Количество\n")
            writer.append("Выполнено,$completed\n")
            writer.append("Активные,$active\n\n")

            writer.append("Категория,Количество\n")
            categories.forEach {
                writer.append("${it.category},${it.count}\n")
            }
        }

        val uri = FileProvider.getUriForFile(
            context,
            context.packageName + ".provider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(intent, "Поделиться CSV"))
    }
}
